import csv
import google.generativeai as genai
import requests
import re
from flask import Flask, request, render_template

# Configuration for GenerativeAI
genai.configure(api_key="AIzaSyBiZPvNW2hPlfxQDF3tVpuYwex26jNVWGw")

# Set up the model
generation_config = {
    "temperature": 0.9,
    "top_p": 1,
    "top_k": 1,
    "max_output_tokens": 2048,
}

safety_settings = [
    {
        "category": "HARM_CATEGORY_HARASSMENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_HATE_SPEECH",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
    {
        "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
        "threshold": "BLOCK_MEDIUM_AND_ABOVE"
    },
]

model = genai.GenerativeModel(model_name="gemini-1.0-pro",
                              generation_config=generation_config,
                              safety_settings=safety_settings)

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/estimate', methods=['POST'])
def estimate():
    brand = request.form['brand']
    ram = request.form['ram']
    storage = request.form['storage']
    matching_rows = []

    # Read data from CSV file
    with open("KSUprices.csv", 'r') as file:
        reader = csv.reader(file)
        header = next(reader)  # Skip header row
        for row in reader:
            if (brand.lower() in row[9].lower()) and \
               (ram.lower() in row[3].lower()) and \
               (storage.lower() in row[4].lower()):
                matching_rows.append(row)

    if matching_rows:
        return render_template('result.html', matching_rows=matching_rows)
    else:
        convo = model.start_chat(history=[])
        convo.send_message(f"Estimate price for the product using the following parameters: Brand - {brand}, RAM - {ram}, Storage - {storage}")
        response_text = convo.last.text
        return render_template('result.html', response_text=response_text)

if __name__ == '__main__':
    app.run(debug=True)
